#!/bin/sh
export DATE_CURRENT=`date +%Y-%m-%d`
export TIME_CURRENT=`date +%Y%m%d%H%M%S`

# Deregister and remove the AMI and Snapshot from N.California Region
oregonRegion=us-west-2


# Deregister and remove the AMI and Snapshot from Oregon Region
AWS_ACCESS_KEY_ID=AKIA4A4FWMXJ3TYAIY66 AWS_SECRET_ACCESS_KEY=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 aws ec2 describe-images --owners self --region $oregonRegion --query 'Images[*].[ImageId,CreationDate,BlockDeviceMappings[0].Ebs.SnapshotId]' > /home/ubuntu/instanceUtils/AMICreationScripts/BarsAMICreationScript/removeBarsAMIs.txt 
amiCount=`wc -l < /home/ubuntu/instanceUtils/AMICreationScripts/BarsAMICreationScript/removeBarsAMIs.txt`
echo $amiCount
        for i in $(seq 1 $amiCount);
        do
        echo $i
        amiCreatedDateTime=`cat /home/ubuntu/instanceUtils/AMICreationScripts/BarsAMICreationScript/removeBarsAMIs.txt | awk -v i=$i 'NR==i{print $2}'`
        amiId=`cat /home/ubuntu/instanceUtils/AMICreationScripts/BarsAMICreationScript/removeBarsAMIs.txt | awk -v i=$i 'NR==i{print $1}'`
        amiCreatedDate=`date -d ${amiCreatedDateTime} +%Y-%m-%d`
        amiCreatedDateTime_EPOCH=`date -d ${amiCreatedDate} +%s`
        currentDate_EPOCH=`date -d ${DATE_CURRENT} +%s`
        difference=`expr $currentDate_EPOCH - $amiCreatedDateTime_EPOCH`
        sleep 2s
        days=`expr $difference / 86400`
               if [ ${days} -ge 14 ];
                then
                echo $i
                AWS_ACCESS_KEY_ID=AKIA4A4FWMXJ3TYAIY66 AWS_SECRET_ACCESS_KEY=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 aws ec2 deregister-image --region $oregonRegion --image-id ${amiId}
                SNAPSHOT_ID=`cat /home/ubuntu/instanceUtils/AMICreationScripts/BarsAMICreationScript/removeBarsAMIs.txt | awk -v i=$i 'NR==i{print $3}'`
                AWS_ACCESS_KEY_ID=AKIA4A4FWMXJ3TYAIY66 AWS_SECRET_ACCESS_KEY=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 aws ec2 delete-snapshot --region $oregonRegion --snapshot-id ${SNAPSHOT_ID}
                sleep 2s
                fi
        done
