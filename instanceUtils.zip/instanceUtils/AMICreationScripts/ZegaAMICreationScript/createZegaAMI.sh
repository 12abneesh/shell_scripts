#!/bin/sh
export DATE_CURRENT=`date +%Y-%m-%d`
export TIME_CURRENT=`date +%Y%m%d%H%M%S`

#ohioRegion=us-east-2

# 1-1 Get the list of instances that you want to create AMI

#INSTANCES=`AWS_ACCESS_KEY_ID=AKIAJ4SEB7SFTDQJ4KJA AWS_SECRET_ACCESS_KEY=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 aws ec2 describe-instances --query 'Reservations[*].Instances[*].InstanceId' --region $oregonRegion`

 # for INSTANCE in ${INSTANCES};
  #do
  # 1-3 Create an AMI
   #AWS_ACCESS_KEY_ID=AKIAJ4SEB7SFTDQJ4KJA AWS_SECRET_ACCESS_KEY=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 aws ec2 create-image --region $oregonRegion --instance-id ${INSTANCE} --name "${INSTANCE}_${TIME_CURRENT}" --no-reboot
   #sleep 10s
  #done

# AMI creation of QA Instance
AWS_ACCESS_KEY_ID=AKIAJZCWBQY4MRUHFHFA AWS_SECRET_ACCESS_KEY=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 aws ec2 create-image --region us-west-2 --instance-id i-01ce97c1770269ca0 --name "i-01ce97c1770269ca0_${TIME_CURRENT}" --no-reboot
if [ $? -eq 0 ]; then
emailtext="/home/ubuntu/instanceUtils/AMICreationScripts/ZegaAMICreationScript/mail.txt"
echo "AMI of Zega instance has been created successfully." >> $emailtext
sudo ssmtp himanshu.jain@hexaviewtech.com, ankit.agarwal@hexaviewtech.com, bhagyashri.jha@hexaviewtech.com < $emailtext
head -n 7 $emailtext > temp.txt ; mv temp.txt $emailtext
else
emailtext="/home/ubuntu/instanceUtils/AMICreationScripts/ZegaAMICreationScript/mail.txt"
echo "AMI of Zega instance has not created. Might be instance id has changed. Please check." >> $emailtext
sudo ssmtp himanshu.jain@hexaviewtech.com, ankit.agarwal@hexaviewtech.com, bhagyashri.jha@hexaviewtech.com < $emailtext
head -n 7 $emailtext > temp.txt ; mv temp.txt $emailtext
fi
