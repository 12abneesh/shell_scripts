#!/bin/sh
export DATE_CURRENT=`date +%Y-%m-%d`
export TIME_CURRENT=`date +%Y%m%d%H%M%S`

# Deregister and remove the AMI and Snapshot from Ohio Region

ohioRegion=us-east-2

AWS_ACCESS_KEY_ID=AKIAJZCWBQY4MRUHFHFA AWS_SECRET_ACCESS_KEY=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 aws ec2 describe-images --owners self --region $ohioRegion --query 'Images[*].[ImageId,CreationDate,BlockDeviceMappings[0].Ebs.SnapshotId]' > /home/ubuntu/instanceUtils/AMICreationScripts/ZegaAMICreationScript/removeZegaAMIsOhio.txt
amiCount=`wc -l < /home/ubuntu/instanceUtils/AMICreationScripts/ZegaAMICreationScript/removeZegaAMIsOhio.txt`
echo $amiCount

        for i in $(seq 1 $amiCount);
        do
        echo $i
        amiCreatedDateTime=`cat /home/ubuntu/instanceUtils/AMICreationScripts/ZegaAMICreationScript/removeZegaAMIsOhio.txt | awk -v i=$i 'NR==i{print $2}'`
        amiId=`cat /home/ubuntu/instanceUtils/AMICreationScripts/ZegaAMICreationScript/removeZegaAMIsOhio.txt | awk -v i=$i 'NR==i{print $1}'`
        amiCreatedDate=`date -d ${amiCreatedDateTime} +%Y-%m-%d`
        amiCreatedDateTime_EPOCH=`date -d ${amiCreatedDate} +%s`
        currentDate_EPOCH=`date -d ${DATE_CURRENT} +%s`
        difference=`expr $currentDate_EPOCH - $amiCreatedDateTime_EPOCH`
        sleep 2s
        days=`expr $difference / 86400`
               if [ ${days} -ge 14 ];
                then
                echo $i
                AWS_ACCESS_KEY_ID=AKIAJZCWBQY4MRUHFHFA AWS_SECRET_ACCESS_KEY=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 aws ec2 deregister-image --region $ohioRegion --image-id ${amiId}
                SNAPSHOT_ID=`cat /home/ubuntu/instanceUtils/AMICreationScripts/ZegaAMICreationScript/removeZegaAMIsOhio.txt | awk -v i=$i 'NR==i{print $3}'`
                AWS_ACCESS_KEY_ID=AKIAJZCWBQY4MRUHFHFA AWS_SECRET_ACCESS_KEY=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 aws ec2 delete-snapshot --region $ohioRegion --snapshot-id ${SNAPSHOT_ID}
                sleep 2s
                fi
        done
