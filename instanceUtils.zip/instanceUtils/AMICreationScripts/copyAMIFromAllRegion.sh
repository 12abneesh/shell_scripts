#!/bin/sh

export DATE_CURRENT=`date +%Y-%m-%d`
export TIME_CURRENT=`date +%Y%m%d%H%M%S`

# Copy AMI from N. California Region

californiaRegion=us-west-1
oregonRegion=us-west-2
virginiaRegion=us-east-1
ohioRegion=us-east-2

aws ec2 describe-images --owners self --region $oregonRegion --query 'Images[*].[ImageId,CreationDate,BlockDeviceMappings[0].Ebs.SnapshotId]' > /home/ubuntu/instanceUtils/AMICreationScripts/allAMIsOregon.txt
amiCount=`wc -l < /home/ubuntu/instanceUtils/AMICreationScripts/allAMIsOregon.txt`
echo $amiCount


        for i in $(seq 1 $amiCount);

        do
        echo $i
        amiCreatedDateTime=`cat /home/ubuntu/instanceUtils/AMICreationScripts/allAMIsOregon.txt | awk -v i=$i 'NR==i{print $2}'`
        amiId=`cat /home/ubuntu/instanceUtils/AMICreationScripts/allAMIsOregon.txt | awk -v i=$i 'NR==i{print $1}'`
        amiCreatedDate=`date -d ${amiCreatedDateTime} +%Y-%m-%d`
        amiCreatedDateTime_EPOCH=`date -d ${amiCreatedDate} +%s`
        currentDate_EPOCH=`date -d ${DATE_CURRENT} +%s`

        difference=`expr $currentDate_EPOCH - $amiCreatedDateTime_EPOCH`
        sleep 2s
        days=`expr $difference / 86400`

               if [ ${days} -le 2 ];
                then
                echo $i

                aws ec2 copy-image --source-image-id $amiId --source-region $oregonRegion --region $ohioRegion --name $amiId

                fi
        done

# California Region

aws ec2 describe-images --owners self --region $californiaRegion --query 'Images[*].[ImageId,CreationDate,BlockDeviceMappings[0].Ebs.SnapshotId]' > /home/ubuntu/instanceUtils/AMICreationScripts/allAMIsCalifornia.txt
amiCount=`wc -l < /home/ubuntu/instanceUtils/AMICreationScripts/allAMIsCalifornia.txt`
echo $amiCount


        for i in $(seq 1 $amiCount);

        do
        echo $i
        amiCreatedDateTime=`cat /home/ubuntu/instanceUtils/AMICreationScripts/allAMIsCalifornia.txt | awk -v i=$i 'NR==i{print $2}'`
        amiId=`cat /home/ubuntu/instanceUtils/AMICreationScripts/allAMIsCalifornia.txt | awk -v i=$i 'NR==i{print $1}'`
        amiCreatedDate=`date -d ${amiCreatedDateTime} +%Y-%m-%d`
        amiCreatedDateTime_EPOCH=`date -d ${amiCreatedDate} +%s`
        currentDate_EPOCH=`date -d ${DATE_CURRENT} +%s`

        difference=`expr $currentDate_EPOCH - $amiCreatedDateTime_EPOCH`
        sleep 2s
        days=`expr $difference / 86400`

               if [ ${days} -le 2 ];
                then
                echo $i

                aws ec2 copy-image --source-image-id $amiId --source-region $californiaRegion --region $ohioRegion --name $amiId

                fi
        done

#Virginia Region

aws ec2 describe-images --owners self --region $virginiaRegion --query 'Images[*].[ImageId,CreationDate,BlockDeviceMappings[0].Ebs.SnapshotId]' > /home/ubuntu/instanceUtils/AMICreationScripts/allAMIsVirginia.txt
amiCount=`wc -l < /home/ubuntu/instanceUtils/AMICreationScripts/allAMIsVirginia.txt`
echo $amiCount


        for i in $(seq 1 $amiCount);

        do
        echo $i
        amiCreatedDateTime=`cat /home/ubuntu/instanceUtils/AMICreationScripts/allAMIsVirginia.txt | awk -v i=$i 'NR==i{print $2}'`
        amiId=`cat /home/ubuntu/instanceUtils/AMICreationScripts/allAMIsVirginia.txt | awk -v i=$i 'NR==i{print $1}'`
        amiCreatedDate=`date -d ${amiCreatedDateTime} +%Y-%m-%d`
        amiCreatedDateTime_EPOCH=`date -d ${amiCreatedDate} +%s`
        currentDate_EPOCH=`date -d ${DATE_CURRENT} +%s`

        difference=`expr $currentDate_EPOCH - $amiCreatedDateTime_EPOCH`
        sleep 2s
        days=`expr $difference / 86400`

               if [ ${days} -le 2 ];
                then
                echo $i

                aws ec2 copy-image --source-image-id $amiId --source-region $virginiaRegion --region $ohioRegion --name $amiId

                fi
        done
