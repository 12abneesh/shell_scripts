#!/bin/sh

export DATE_CURRENT=`date +%Y-%m-%d`
export TIME_CURRENT=`date +%Y%m%d%H%M%S`

# Deregister and remove the AMI and Snapshot
#amiCount=`wc -l < /home/ubuntu/instanceUtils/AMICreationScripts/allAMIDetails.txt`
#echo $amiCount

region=us-west-1

aws ec2 describe-images --owners self --region $region --query 'Images[*].[ImageId,CreationDate,BlockDeviceMappings[0].Ebs.SnapshotId]' > /home/ubuntu/instanceUtils/AMICreationScripts/allAMIs.txt
amiCount=`wc -l < /home/ubuntu/instanceUtils/AMICreationScripts/allAMIs.txt`
echo $amiCount


        for i in $(seq 1 $amiCount);
        do

        echo $i
        amiCreatedDateTime=`cat /home/ubuntu/instanceUtils/AMICreationScripts/allAMIs.txt | awk -v i=$i 'NR==i{print $2}'`
        amiId=`cat /home/ubuntu/instanceUtils/AMICreationScripts/allAMIs.txt | awk -v i=$i 'NR==i{print $1}'`
        amiCreatedDate=`date -d ${amiCreatedDateTime} +%Y-%m-%d`
        amiCreatedDateTime_EPOCH=`date -d ${amiCreatedDate} +%s`
        currentDate_EPOCH=`date -d ${DATE_CURRENT} +%s`

        difference=`expr $currentDate_EPOCH - $amiCreatedDateTime_EPOCH`
        sleep 2s
        days=`expr $difference / 86400`

               if [ ${days} -le 2 ];
                then
                echo $i

		aws ec2 copy-image --source-image-id $amiId --source-region $region --region us-east-2 --name $amiId

                fi
        done
