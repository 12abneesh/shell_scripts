#!/bin/bash

export DATE_CURRENT=`date +%Y-%m-%d`
export TIME_CURRENT=`date +%Y%m%d%H%M%S`

# 1-1 Get the list of instances that you want to create AMI
aws ec2 describe-instances --output text --query 'Reservations[*].Instances[*].[InstanceId,Tags[?Key==`Name`].Value]' --region us-west-1 > /home/ubuntu/instanceUtils/AMICreationScripts/output3.txt

sleep 3s
#instanceCount = wc -l < /home/ubuntu/instanceUtils/AMICreationScripts/output3.txt
#echo $instanceCount

	region=us-west-1
#        INSTANCES=`aws ec2 describe-instances --query 'Reservations[*].Instances[*].InstanceId' --region $region`

#INSTANCES=`aws ec2 describe-instances --output text --query 'Reservations[*].Instances[*].[InstanceId,Tags[?Key==`Name`].Value]' --region us-west-1`

#        for INSTANCE in ${INSTANCES};
 #       do

                # 1-3 Create an AMI
  #              aws ec2 create-image --region $region --instance-id ${INSTANCE} --name "${INSTANCE}_${TIME_CURRENT}" --no-reboot


#	for((i=1; i<= 20; i+=2));do

	instanceId = `cat /home/ubuntu/instanceUtils/AMICreationScripts/output3.txt | awk -v i=$i 'NR==i{print $1}'`
	aws ec2 create-image --region us-west-1 --instance-id $instanceId --name "$instanceId_${TIME_CURRENT}" --no-reboot
	projectName =`cat /home/ubuntu/instanceUtils/AMICreationScripts/output3.txt | awk -v i=$i 'NR==++i{print $1}'`
		emailtext="/home/ubuntu/instanceUtils/AMICreationScripts/mail.txt"
		echo "AMI of project: $projectName has been created successfully." >> $emailtext
#		sudo ssmtp himanshu.jain@hexaviewtech.com, ankit.agarwal@hexaviewtech.com < $emailtext
		sudo ssmtp himanshu.jain@hexaviewtech.com < $emailtext
		head -n 7 $emailtext > temp.txt ; mv temp.txt $emailtext

        done
