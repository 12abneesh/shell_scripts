#!/bin/sh

export DATE_CURRENT=`date +%Y-%m-%d`
export TIME_CURRENT=`date +%Y%m%d%H%M%S`

# 1-1 Get the list of instances that you want to create AMI
aws ec2 describe-instances --output text --query 'Reservations[*].Instances[*].[InstanceId,Tags[?Key==`Name`].Value]' --region us-west-1 > /home/ubuntu/instanceUtils/AMICreationScripts/output3.txt


more /home/ubuntu/instanceUtils/AMICreationScripts/output3.txt | awk -v i=1 'NR==i{print $1}'

sleep 3s
region=us-west-1
#name = ( Name )
#INSTANCES=aws ec2 describe-instances --output text --query 'Reservations[*].Instances[*].[InstanceId,Tags[?Key==$name].Value]' --region us-west-1

#i=2
   #     for INSTANCE in ${INSTANCES};
	for i in 20;
      do
                # 1-3 Create an AMI
echo $i
		projectName =`cat /home/ubuntu/instanceUtils/AMICreationScripts/output3.txt | awk -v i=2 'NR==i{print $1}'`
		emailtext="/home/ubuntu/instanceUtils/AMICreationScripts/mail.txt"
		echo "AMI of project: $projectName has been created successfully." >> $emailtext
#		sudo ssmtp himanshu.jain@hexaviewtech.com, ankit.agarwal@hexaviewtech.com < $emailtext
		sudo ssmtp himanshu.jain@hexaviewtech.com < $emailtext
		head -n 7 $emailtext > temp.txt ; mv temp.txt $emailtext

		i=$(expr $i + 2)
        done
