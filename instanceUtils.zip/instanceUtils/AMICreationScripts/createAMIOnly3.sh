#!/bin/sh

export DATE_CURRENT=`date +%Y-%m-%d`
export TIME_CURRENT=`date +%Y%m%d%H%M%S`

# 1-1 Get the list of instances that you want to create AMI
aws ec2 describe-instances --output text --query 'Reservations[*].Instances[*].[InstanceId,Tags[?Key==`Name`].Value]' --region us-west-1 > /home/ubuntu/instanceUtils/AMICreationScripts/output3.txt
instanceCount=`wc -l < /home/ubuntu/instanceUtils/AMICreationScripts/output3.txt`
echo $instanceCount
sleep 2s
region=us-west-1

        for i in $(seq 1 $instanceCount);
      do
                # 1-3 Create an AMI
		if [ `expr $i % 2` -eq 1 ];
		then
		instanceId=`cat /home/ubuntu/instanceUtils/AMICreationScripts/output3.txt | awk -v i=$i 'NR==i{print $1}'`
	        aws ec2 create-image --region us-west-1 --instance-id $instanceId --name "${instanceId}_${TIME_CURRENT}" --no-reboot
		i=`expr $i + 1`
                projectName=`cat /home/ubuntu/instanceUtils/AMICreationScripts/output3.txt | awk -v i=$i 'NR==i{print $1}'`
                emailtext="/home/ubuntu/instanceUtils/AMICreationScripts/mail.txt"
                echo "AMI of project: $projectName has been created successfully." >> $emailtext
#               sudo ssmtp himanshu.jain@hexaviewtech.com, ankit.agarwal@hexaviewtech.com < $emailtext
                sudo ssmtp himanshu.jain@hexaviewtech.com < $emailtext
                head -n 7 $emailtext > temp.txt ; mv temp.txt $emailtext
		fi
        done
