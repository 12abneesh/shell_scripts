#!/bin/sh

export DATE_CURRENT=`date +%Y-%m-%d`
export TIME_CURRENT=`date +%Y%m%d%H%M%S`

californiaRegion=us-west-1
virginiaRegion=us-east-1
oregonRegion=us-west-2


# 1-1 Get the list of instances that you want to create AMI
# AMI creation of N. California Region

aws ec2 describe-instances --output text --query 'Reservations[*].Instances[*].[InstanceId,Tags[?Key==`Name`].Value]' --region $californiaRegion > /home/ubuntu/instanceUtils/AMICreationScripts/instanceDetails.txt
instanceCount=`wc -l < /home/ubuntu/instanceUtils/AMICreationScripts/instanceDetails.txt`
echo $instanceCount

        for i in $(seq 1 $instanceCount);
      do
                # 1-3 Create an AMI
                if [ `expr $i % 2` -eq 1 ];
                then
                instanceId=`cat /home/ubuntu/instanceUtils/AMICreationScripts/instanceDetails.txt | awk -v i=$i 'NR==i{print $1}'`
                aws ec2 create-image --region $californiaRegion --instance-id $instanceId --name "${instanceId}_${TIME_CURRENT}" --no-reboot
                i=`expr $i + 1`
                projectName=`cat /home/ubuntu/instanceUtils/AMICreationScripts/instanceDetails.txt | awk -v i=$i 'NR==i{print $1}'`
                emailtext="/home/ubuntu/instanceUtils/AMICreationScripts/mail.txt"
                echo "AMI of project: $projectName has been created successfully." >> $emailtext
                sudo ssmtp himanshu.jain@hexaviewtech.com, ankit.agarwal@hexaviewtech.com < $emailtext
                head -n 6 $emailtext > temp.txt ; mv temp.txt $emailtext
                fi
      done

sleep 15s

# AMI creation of N. Virginia Region
#old script
#	INSTANCES=`aws ec2 describe-instances --query 'Reservations[*].Instances[*].InstanceId' --region $virginiaRegion`
#        for INSTANCE in ${INSTANCES};
#        do
                # 1-3 Create an AMI
#                aws ec2 create-image --region $virginiaRegion --instance-id ${INSTANCE} --name "${INSTANCE}_${TIME_CURRENT}" --no-reboot
#                sleep 10s
#        done

#New Script

aws ec2 describe-instances --output text --query 'Reservations[*].Instances[*].[InstanceId,Tags[?Key==`Name`].Value]' --region $virginiaRegion > /home/ubuntu/instanceUtils/AMICreationScripts/instanceDetails.txt
instanceCount=`wc -l < /home/ubuntu/instanceUtils/AMICreationScripts/instanceDetails.txt`
echo $instanceCount

        for i in $(seq 1 $instanceCount);
      do
                # 1-3 Create an AMI
                if [ `expr $i % 2` -eq 1 ];
                then
                instanceId=`cat /home/ubuntu/instanceUtils/AMICreationScripts/instanceDetails.txt | awk -v i=$i 'NR==i{print $1}'`
                aws ec2 create-image --region $virginiaRegion --instance-id $instanceId --name "${instanceId}_${TIME_CURRENT}" --no-reboot
                i=`expr $i + 1`
                projectName=`cat /home/ubuntu/instanceUtils/AMICreationScripts/instanceDetails.txt | awk -v i=$i 'NR==i{print $1}'`
                emailtext="/home/ubuntu/instanceUtils/AMICreationScripts/mail.txt"
                echo "AMI of project: $projectName has been created successfully." >> $emailtext
                sudo ssmtp himanshu.jain@hexaviewtech.com, ankit.agarwal@hexaviewtech.com < $emailtext
                head -n 6 $emailtext > temp.txt ; mv temp.txt $emailtext
                fi
      done

sleep 15s
# AMI creation of Oregon Region
aws ec2 describe-instances --output text --query 'Reservations[*].Instances[*].[InstanceId,Tags[?Key==`Name`].Value]' --region $oregonRegion > /home/ubuntu/instanceUtils/AMICreationScripts/instanceDetails.txt
instanceCount=`wc -l < /home/ubuntu/instanceUtils/AMICreationScripts/instanceDetails.txt`
echo $instanceCount

        for i in $(seq 1 $instanceCount);
      do
                # 1-3 Create an AMI
                if [ `expr $i % 2` -eq 1 ];
                then
                instanceId=`cat /home/ubuntu/instanceUtils/AMICreationScripts/instanceDetails.txt | awk -v i=$i 'NR==i{print $1}'`
                aws ec2 create-image --region $oregonRegion --instance-id $instanceId --name "${instanceId}_${TIME_CURRENT}" --no-reboot
                i=`expr $i + 1`
                projectName=`cat /home/ubuntu/instanceUtils/AMICreationScripts/instanceDetails.txt | awk -v i=$i 'NR==i{print $1}'`
                emailtext="/home/ubuntu/instanceUtils/AMICreationScripts/mail.txt"
                echo "AMI of project: $projectName has been created successfully." >> $emailtext
                sudo ssmtp himanshu.jain@hexaviewtech.com, ankit.agarwal@hexaviewtech.com < $emailtext
                head -n 6 $emailtext > temp.txt ; mv temp.txt $emailtext
                fi
      done
