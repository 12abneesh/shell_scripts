#!/bin/sh

export DATE_CURRENT=`date +%Y-%m-%d`
export TIME_CURRENT=`date +%Y%m%d%H%M%S`

# Deregister and remove the AMI and Snapshot
#amiCount=`wc -l < /home/ubuntu/instanceUtils/AMICreationScripts/allAMIDetails.txt`
#echo $amiCount

region=us-west-1

aws ec2 describe-images --owners self --region $region --query 'Images[*].[ImageId,CreationDate,BlockDeviceMappings[0].Ebs.SnapshotId]' > /home/ubuntu/instanceUtils/AMICreationScripts/removeAMIs.txt
amiCount=`wc -l < /home/ubuntu/instanceUtils/AMICreationScripts/removeAMIs.txt`
echo $amiCount

        for i in $(seq 1 $amiCount);

        do
        echo $i
        amiCreatedDateTime=`cat /home/ubuntu/instanceUtils/AMICreationScripts/removeAMIs.txt | awk -v i=$i 'NR==i{print $2}'`
        amiId=`cat /home/ubuntu/instanceUtils/AMICreationScripts/removeAMIs.txt | awk -v i=$i 'NR==i{print $1}'`
        amiCreatedDate=`date -d ${amiCreatedDateTime} +%Y-%m-%d`
        amiCreatedDateTime_EPOCH=`date -d ${amiCreatedDate} +%s`
        currentDate_EPOCH=`date -d ${DATE_CURRENT} +%s`

        difference=`expr $currentDate_EPOCH - $amiCreatedDateTime_EPOCH`
        sleep 2s
        days=`expr $difference / 86400`

               if [ ${days} -ge 14 ];
                then
                echo $i
                aws ec2 deregister-image --region $region --image-id ${amiId}
                SNAPSHOT_ID=`cat /home/ubuntu/instanceUtils/AMICreationScripts/removeAMIs.txt | awk -v i=$i 'NR==i{print $3}'`
                aws ec2 delete-snapshot --region $region --snapshot-id ${SNAPSHOT_ID}
#                if [ $? -eq 0 ]; then
#                        sed -i '/'$SNAPSHOT_ID'/ d' /home/ubuntu/instanceUtils/AMICreationScripts/removeAMIs.txt
#
#                fi
                sleep 2s
                fi
        done
