#!/bin/sh

export DATE_CURRENT=`date +%Y-%m-%d`
export TIME_CURRENT=`date +%Y%m%d%H%M%S`

# Deregister and remove the AMI and Snapshot from N.California Region
californiaRegion=us-west-1
oregonRegion=us-west-2
virginiaRegion=us-east-1

aws ec2 describe-images --owners self --region $californiaRegion --query 'Images[*].[ImageId,CreationDate,BlockDeviceMappings[0].Ebs.SnapshotId]' > /home/ubuntu/instanceUtils/AMICreationScripts/removeAMIsCalifornia.txt
amiCount=`wc -l < /home/ubuntu/instanceUtils/AMICreationScripts/removeAMIsCalifornia.txt`
echo $amiCount

        for i in $(seq 1 $amiCount);
        do
        echo $i
        amiCreatedDateTime=`cat /home/ubuntu/instanceUtils/AMICreationScripts/removeAMIsCalifornia.txt | awk -v i=$i 'NR==i{print $2}'`
        amiId=`cat /home/ubuntu/instanceUtils/AMICreationScripts/removeAMIsCalifornia.txt | awk -v i=$i 'NR==i{print $1}'`
        amiCreatedDate=`date -d ${amiCreatedDateTime} +%Y-%m-%d`
        amiCreatedDateTime_EPOCH=`date -d ${amiCreatedDate} +%s`
        currentDate_EPOCH=`date -d ${DATE_CURRENT} +%s`

        difference=`expr $currentDate_EPOCH - $amiCreatedDateTime_EPOCH`
        sleep 2s
        days=`expr $difference / 86400`

               if [ ${days} -ge 14 ];
                then
                echo $i
                aws ec2 deregister-image --region $californiaRegion --image-id ${amiId}
                SNAPSHOT_ID=`cat /home/ubuntu/instanceUtils/AMICreationScripts/removeAMIsCalifornia.txt | awk -v i=$i 'NR==i{print $3}'`
                aws ec2 delete-snapshot --region $californiaRegion --snapshot-id ${SNAPSHOT_ID}

                sleep 2s
                fi
        done
sleep 1m
# Deregister and remove the AMI and Snapshot from Oregon Region

aws ec2 describe-images --owners self --region $oregonRegion --query 'Images[*].[ImageId,CreationDate,BlockDeviceMappings[0].Ebs.SnapshotId]' > /home/ubuntu/instanceUtils/AMICreationScripts/removeAMIsOregon.txt
amiCount=`wc -l < /home/ubuntu/instanceUtils/AMICreationScripts/removeAMIsOregon.txt`
echo $amiCount

        for i in $(seq 1 $amiCount);
        do
        echo $i
        amiCreatedDateTime=`cat /home/ubuntu/instanceUtils/AMICreationScripts/removeAMIsOregon.txt | awk -v i=$i 'NR==i{print $2}'`
        amiId=`cat /home/ubuntu/instanceUtils/AMICreationScripts/removeAMIsOregon.txt | awk -v i=$i 'NR==i{print $1}'`
        amiCreatedDate=`date -d ${amiCreatedDateTime} +%Y-%m-%d`
        amiCreatedDateTime_EPOCH=`date -d ${amiCreatedDate} +%s`
        currentDate_EPOCH=`date -d ${DATE_CURRENT} +%s`

        difference=`expr $currentDate_EPOCH - $amiCreatedDateTime_EPOCH`
        sleep 2s
        days=`expr $difference / 86400`

               if [ ${days} -ge 14 ];
                then
                echo $i
                aws ec2 deregister-image --region $oregonRegion --image-id ${amiId}
                SNAPSHOT_ID=`cat /home/ubuntu/instanceUtils/AMICreationScripts/removeAMIsOregon.txt | awk -v i=$i 'NR==i{print $3}'`
                aws ec2 delete-snapshot --region $oregonRegion --snapshot-id ${SNAPSHOT_ID}

                sleep 2s
                fi
        done
sleep 1m
# Deregister and remove the AMI and Snapshot from Virginia Region

aws ec2 describe-images --owners self --region $virginiaRegion --query 'Images[*].[ImageId,CreationDate,BlockDeviceMappings[0].Ebs.SnapshotId]' > /home/ubuntu/instanceUtils/AMICreationScripts/removeAMIsVirginia.txt
amiCount=`wc -l < /home/ubuntu/instanceUtils/AMICreationScripts/removeAMIsVirginia.txt`
echo $amiCount

        for i in $(seq 1 $amiCount);
        do
        echo $i
        amiCreatedDateTime=`cat /home/ubuntu/instanceUtils/AMICreationScripts/removeAMIsVirginia.txt | awk -v i=$i 'NR==i{print $2}'`
        amiId=`cat /home/ubuntu/instanceUtils/AMICreationScripts/removeAMIsVirginia.txt | awk -v i=$i 'NR==i{print $1}'`
        amiCreatedDate=`date -d ${amiCreatedDateTime} +%Y-%m-%d`
        amiCreatedDateTime_EPOCH=`date -d ${amiCreatedDate} +%s`
        currentDate_EPOCH=`date -d ${DATE_CURRENT} +%s`

        difference=`expr $currentDate_EPOCH - $amiCreatedDateTime_EPOCH`
        sleep 2s
        days=`expr $difference / 86400`

               if [ ${days} -ge 14 ];
                then
                echo $i
                aws ec2 deregister-image --region $virginiaRegion --image-id ${amiId}
                SNAPSHOT_ID=`cat /home/ubuntu/instanceUtils/AMICreationScripts/removeAMIsVirginia.txt | awk -v i=$i 'NR==i{print $3}'`
                aws ec2 delete-snapshot --region $virginiaRegion --snapshot-id ${SNAPSHOT_ID}

                sleep 2s
                fi
        done
