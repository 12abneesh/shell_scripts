echo /home/ubuntu/instanceUtils/AMICreationScripts/output3.txt | awk -v i=2 'NR==i{print $1}'
