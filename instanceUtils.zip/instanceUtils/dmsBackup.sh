#!/bin/bash
key_file=/home/ubuntu/instanceUtils/dms_keys/Hvt_DMS.pem
server_ip=172.31.2.168
current_time=$(date "+%Y%m%d-%H%M%S")
zipname=backup_$current_time

ssh -i $key_file ubuntu@$server_ip "sh /home/ubuntu/$1 $zipname"
scp -i $key_file ubuntu@$server_ip:/home/ubuntu/$zipname.zip /home/ubuntu
aws s3 --region us-west-1 cp /home/ubuntu/$zipname.zip s3://$2
ssh -i $key_file ubuntu@$server_ip "rm -rf /home/ubuntu/$zipname.zip"
rm /home/ubuntu/$zipname.zip

