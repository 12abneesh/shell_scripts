#!/bin/bash

echo "initiating space check!"

size=$1
#echo $usize
mailtext="/home/ubuntu/instanceUtils"
free=`df | awk 'NR==4 {print($1="/dev/xvda1") ? $4 : ""}'`
result=`python -c "print ${free} - ${size}"`
echo $result
if echo $result | grep "-"
then
   emailtext="/home/ubuntu/instanceUtils/reporting.txt"
   echo "Backup is not complete. Reportwa DEMO UI instance is out of memory. Please check." >> $emailtext
   #sudo ssmtp keshav.goyal@hexaviewtech.com -F "hexaviewnotification@gmail.com" < $emailtext
   sudo ssmtp ankit.agarwal@hexaviewtech.com, keshav.goyal@hexaviewtech.com -F "hexaviewnotification@gmail.com" < $emailtext
   head -n 7 $emailtext > temp.txt ; mv temp.txt $emailtext
   echo "It's there."
   return 1
else
   echo "false"
fi

