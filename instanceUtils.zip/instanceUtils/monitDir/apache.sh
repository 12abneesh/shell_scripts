#!/bin/bash
case $1 in
    start)

	sudo service apache2 start

    sendEmail -f himanshu.jain@hexaviewtech.com -t ankit.agarwal@hexaviewtech.com -cc himanshu.jain@hexaviewtech.com -u "Monit Update" -m "Hi \n\n Apache Stopped working but was restarted.\n\n Thanks" -s email-smtp.us-east-1.amazonaws.com:25 -xu AKIAJNXT3KYRBG35GESA -xp Ar0/auyzx8kqMK9C6z3mQ6l2OEBeEvCas6YcdcOOJTRt

  ;;
     stop)
       sudo service apache2 stop
       ;;
 esac
 exit 0

