#!/bin/bash
sendEmail -f vijay@hexaviewtech.com -t ankit.agarwal@hexaviewtech.com -cc ravi.kumar@hexaviewtech.com -u "Monit Update" -m "Hi \n\n MongoDB Stopped working but was restarted. \n\n Also PFA last 100 lines of the Log file \n\n Thanks" -a /home/ubuntu/tempLog.txt -s email-smtp.us-east-1.amazonaws.com:25 -xu AKIAJNXT3KYRBG35GESA -xp Ar0/auyzx8kqMK9C6z3mQ6l2OEBeEvCas6YcdcOOJTRt
rm /home/ubuntu/tempLog.txt
