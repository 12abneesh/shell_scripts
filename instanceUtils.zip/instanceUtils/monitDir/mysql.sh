#!/bin/bash

sendEmail -f vijay@hexaviewtech.com -t ankit.agarwal@hexaviewtech.com -cc vijay@hexaviewtech.com -u "Monit Update" -m "Hi \n\n MySQL Stopped working but was restarted \n\n Thanks" -s email-smtp.us-east-1.amazonaws.com:25 -xu AKIAJNXT3KYRBG35GESA -xp Ar0/auyzx8kqMK9C6z3mQ6l2OEBeEvCas6YcdcOOJTRt
