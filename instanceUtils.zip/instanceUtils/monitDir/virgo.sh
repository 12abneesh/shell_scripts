#!/bin/sh
case $1 in
    start)

su - ubuntu -c "sh /home/ubuntu/qaEnv/virgo-tomcat-stable/vts/bin/startup.sh > /dev/null 2> /dev/null < /dev/null > /home/ubuntu/instanceUtils/monitDir/virgoConsoleOutput.txt &"
sleep 2m
        if grep -i "Started plan 'ES' version" /home/ubuntu/instanceUtils/monitDir/virgoConsoleOutput.txt
then

sendEmail -f keshav.goyal@hexaviewtech.com -t ankit.agarwal@hexaviewtech.com -cc keshav.goyal@hexaviewtech.com -u "Monit Reportwa DEMO Update" -m "Hi \n\n Virgo Stopped working but was restarted on Demo instance.\n\n Thanks" -s email-smtp.us-east-1.amazonaws.com:25 -xu AKIAJNXT3KYRBG35GESA -xp Ar0/auyzx8kqMK9C6z3mQ6l2OEBeEvCas6YcdcOOJTRt

else

sendEmail -f keshav.goyal@hexaviewtech.com -t ankit.agarwal@hexaviewtech.com -cc keshav.goyal@hexaviewtech.com -u "Monit Reportwa DEMO Update" -m "Hi \n\n Virgo server has not restarted on Demo instance.\n\n Thanks" -s email-smtp.us-east-1.amazonaws.com:25 -xu AKIAJNXT3KYRBG35GESA -xp Ar0/auyzx8kqMK9C6z3mQ6l2OEBeEvCas6YcdcOOJTRt


#sudo ssmtp vijay@hexaviewtech.com < /home/ubuntu/monitDir/mail-virgo.txt

fi
       ;;
     stop)
       sudo fuser -k 9213/tcp
       ;;
esac
exit 0

