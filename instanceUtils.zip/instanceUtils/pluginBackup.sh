#!/bin/bash

current_time=$(date "+%Y%m%d-%H%M%S")
zipname=prod_backup_$current_time

ssh -i /home/ubuntu/instanceUtils/alphaKey.pem ubuntu@172.31.6.44 "sudo sh /home/ubuntu/instanceUtils/backupScripts/runReportWABackup.sh $zipname"

sed -i '/Backup/d' /home/ubuntu/instanceUtils/reporting.txt
sed -i '/upload/d' /home/ubuntu/instanceUtils/reporting.txt

echo "back to main script"
if [ -e /home/ubuntu/instanceUtils/$zipname.zip ];
then
aws s3 cp /home/ubuntu/instanceUtils/$zipname.zip s3://reportwa-db-backup > /home/ubuntu/instanceUtils/s3BucketUploadConsoleOutput.txt
if [ $? -eq 0 ];
then
grep -o 'upload:.*' /home/ubuntu/instanceUtils/s3BucketUploadConsoleOutput.txt > /home/ubuntu/instanceUtils/s3BucketUploadFilteredOutput.txt
fi
#sleep 15s

emailtext="/home/ubuntu/instanceUtils/reporting.txt"
echo "Backup of both MySQL and Mongo DB is uploaded to S3 bucket '"reportwa-db-backup"' with name $zipname" >> $emailtext
cat /home/ubuntu/instanceUtils/s3BucketUploadFilteredOutput.txt >> $emailtext
sudo ssmtp ankit.agarwal@hexaviewtech.com, keshav.goyal@hexaviewtech.com -F "hexaviewnotification@gmail.com" < $emailtext
head -n 7 $emailtext > temp.txt ; mv temp.txt $emailtext
else
echo "file not found!"
fi

# remove file
rm /home/ubuntu/instanceUtils/$zipname.zip
