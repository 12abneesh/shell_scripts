#!/bin/bash


/sbin/iptables -D INPUT -s 171.61.144.111 -p tcp --dport 22 -j ACCEPT
/sbin/iptables -D INPUT -s 171.61.144.111 -p tcp --dport 22 -j ACCEPT
/sbin/iptables -D INPUT -s 203.122.11.246 -p tcp --dport 22 -j ACCEPT
/sbin/iptables -D INPUT -s 122.177.65.2 -p tcp --dport 22 -j ACCEPT
/sbin/iptables -D INPUT -s 203.122.11.246 -p tcp --dport 22 -j ACCEPT
/sbin/iptables -D INPUT -s 203.122.11.246 -p tcp --dport 22 -j ACCEPT
/sbin/iptables -D INPUT -s 203.122.11.246 -p tcp --dport 22 -j ACCEPT
/sbin/iptables -D INPUT -s 171.61.191.148 -p tcp --dport 22 -j ACCEPT
/sbin/iptables -D INPUT -s 171.61.191.148 -p tcp --dport 22 -j ACCEPT
/sbin/iptables -D INPUT -s 203.122.11.246 -p tcp --dport 22 -j ACCEPT
/sbin/iptables -D INPUT -s 203.122.11.246 -p tcp --dport 22 -j ACCEPT
/sbin/iptables -D INPUT -s 203.122.11.246 -p tcp --dport 22 -j ACCEPT
/sbin/iptables -D INPUT -s 203.122.11.246 -p tcp --dport 22 -j ACCEPT
/sbin/iptables -D INPUT -s 203.122.11.246 -p tcp --dport 22 -j ACCEPT
/sbin/iptables -D INPUT -s 203.122.11.246 -p tcp --dport 22 -j ACCEPT
/sbin/iptables -D INPUT -s 203.122.11.246 -p tcp --dport 22 -j ACCEPT
/sbin/iptables -D INPUT -s 203.122.11.246 -p tcp --dport 22 -j ACCEPT
/sbin/iptables -D INPUT -s 203.122.11.246 -p tcp --dport 22 -j ACCEPT
/sbin/iptables -D INPUT -s 203.122.11.246 -p tcp --dport 22 -j ACCEPT
/sbin/iptables -D INPUT -s 203.122.11.246 -p tcp --dport 22 -j ACCEPT
/sbin/iptables -D INPUT -s 203.122.11.246 -p tcp --dport 22 -j ACCEPT
/sbin/iptables -D INPUT -s 203.122.11.246 -p tcp --dport 22 -j ACCEPT
/sbin/iptables -D INPUT -s 172.31.6.44 -p tcp --dport 22 -j ACCEPT
/sbin/iptables -D INPUT -s 172.31.6.44 -p tcp --dport 22 -j ACCEPT
/sbin/iptables -D INPUT -s 13.56.72.110 -p tcp --dport 22 -j ACCEPT
