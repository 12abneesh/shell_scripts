#!/bin/bash

takeShutdownAction ()
{
statusCheck=`aws ec2 describe-instances --region $2 --filters "Name=instance-state-code,Values=16" --instance-id $1`
if [ ! -z "$statusCheck" ]; then
aws ec2 stop-instances --region $2 --instance-ids $1
fi
}

# (Hvt_Custom_Prod)
#takeShutdownAction i-0e4c5e1acf3ed6aa0 us-west-2

# (Hvt_Cassandra_Prod)
#takeShutdownAction i-065c80053114c55f0 us-west-2

# (Hvt_Custom_Reporting)
takeShutdownAction i-087a50f02ac39ca07 us-west-2

# (AxysAim)
takeShutdownAction i-08eedd0dd018717a8 us-west-2

# (Hvt_Cassandra_DB)
takeShutdownAction i-0f28fe3f7326ed72b us-west-2

# (Hvt_Wealth_NewsMate)
takeShutdownAction i-0f239b31ff193c012 us-west-2

# (AxysAimRecon - Reporting Portal)
#takeShutdownAction i-0026637605b2824a8 us-west-1

# (Hvt_DMS_SVN)
#takeShutdownAction i-066c50967e6e5d6e5 us-west-1

# (Hvt_DMS)
#takeShutdownAction i-07a0544d1883984fb us-west-1


