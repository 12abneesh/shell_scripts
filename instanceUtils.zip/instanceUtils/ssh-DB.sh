#!/bin/bash

ssh -i /home/ubuntu/instanceUtils/alphaKey.pem ubuntu@172.31.6.44
