#!/bin/bash

sh /home/ubuntu/instanceUtils/removeIP.sh
cp /home/ubuntu/instanceUtils/removeIP_temp.sh /home/ubuntu/instanceUtils/removeIP.sh
