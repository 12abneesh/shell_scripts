#!/bin/sh

AWS_ACCESS_KEY_ID=AKIA4A4FWMXJ3TYAIY66 AWS_SECRET_ACCESS_KEY=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 aws ec2 stop-instances --region us-west-2 --instance-ids i-0b91725ca64f1260e

#Mail Setup
emailtext="/home/ubuntu/instanceUtils/startStopBarsInstances/instanceStartStopMail.txt"
echo "Bars QA Instance have been stopped successfully" >> $emailtext
sudo ssmtp shweta.sanger@hexaviewtech.com, ankit.agarwal@hexaviewtech.com, divyam.srivastava@hexaviewtech.com < $emailtext
head -n 6 $emailtext > temp.txt ; mv temp.txt $emailtext
