#!/bin/bash
region=us-west-1

