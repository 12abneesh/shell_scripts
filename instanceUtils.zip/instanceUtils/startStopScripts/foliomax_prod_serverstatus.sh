#!/bin/bash



AWS_ACCESS_KEY_ID=AKIA5V5OU3KBQ4YASA7B AWS_SECRET_ACCESS_KEY=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 aws ec2 start-instances --region us-west-1 --instance-ids i-0a1e8$



AWS_ACCESS_KEY_ID=AKIA5V5OU3KBQ4YASA7B AWS_SECRET_ACCESS_KEY=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 aws ec2 start-instances --region us-west-1 --instance-ids i-00109$

#Mail Setup
emailtext="/home/ubuntu/instanceUtils/startStopScripts/instanceStartStopMail.txt"
echo "FolioMax Instances have been started successfully" >> $emailtext
sudo ssmtp neha.kumari@hexaviewtech.com, ankit.agarwal@hexaviewtech.com, santosh.bindra@hexaviewtech.com < $emailtext
head -n 6 $emailtext > temp.txt ; mv temp.txt $emailtext

