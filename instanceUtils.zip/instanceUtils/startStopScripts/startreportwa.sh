
#!/bin/bash
region=us-west-1
#reportwa QA UI

statusa=`aws ec2 describe-instances --output text --query 'Reservations[*].Instances[*].[State.[Code]]'  --region $region --instance-ids i-0297cc9309b2d3373`
sleep 1s
if [ $statusa -eq 80 ]; then
    aws ec2 start-instances --region $region --instance-ids i-0297cc9309b2d3373
    if [ $? -eq 0 ]; then
        #reportwa QA DB
        statusb=`aws ec2 describe-instances --output text --query 'Reservations[*].Instances[*].[State.[Code]]'  --region $region --instance-ids i-0ba73ec625034b3dc`
sleep 1s
        if [ $statusb -eq 80 ]; then
            aws ec2 start-instances --region $region --instance-ids i-0ba73ec625034b3dc
            if [ $? -eq 0 ]; then
                #test plugin server
                statusc=`aws ec2 describe-instances --output text --query 'Reservations[*].Instances[*].[State.[Code]]'  --region $region --instance-ids i-0a456655486cc3d07`
                if [ $statusc -eq 80 ]; then
                    aws ec2 start-instances --region $region --instance-ids i-0a456655486cc3d07
                    if [ $? -eq 0 ]; then
        	                sleep 2m
				PublicDnsName=`aws ec2 describe-instances --output text --query 'Reservations[*].Instances[*].[PublicDnsName]'  --region us-west-1 --instance-ids i-0a456655486cc3d07`
				emailtext="/home/ubuntu/instanceUtils/startStopScripts/Mail.txt"
                       		echo "Reportwa-QA Instances server have been started successfully, Public DNS of Plugin_test server $PublicDnsName" >> $emailtext
                      		sudo ssmtp keshav.goyal@hexaviewtech.com, ankit.agarwal@hexaviewtech.com < $emailtext
          	                head -n 6 $emailtext > temp.txt ; mv temp.txt $emailtext
              fi
	    fi
           fi
          fi
	 fi
    else
    emailtext="/home/ubuntu/instanceUtils/startStopScripts/Mail.txt"
    echo "Reportwa-QA Instances were already started" >> $emailtext
    #sudo ssmtp keshav.goyal@hexaviewtech.com < $emailtext
    sudo ssmtp keshav.goyal@hexaviewtech.com, ankit.agarwal@hexaviewtech.com < $emailtext
    head -n 6 $emailtext > temp.txt ; mv temp.txt $emailtext
    fi
