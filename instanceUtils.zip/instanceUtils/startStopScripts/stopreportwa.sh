
#!/bin/bash
region=us-west-1


aws ec2 describe-instances --query 'Reservations[*].Instances[*].InstanceId' --region $region


#reportwa-qa db instance

aws ec2 stop-instances --region $region --instance-ids i-0ba73ec625034b3dc

#reportwa-qa UI instance

aws ec2 stop-instances --region $region --instance-ids i-0297cc9309b2d3373

#reportwa-qa rabbitMQ instance

aws ec2 stop-instances --region $region --instance-ids i-0a456655486cc3d07

#reportwa-videotemplate isntance

aws ec2 stop-instances --region $region --instance-ids i-0a19bdb1d2750cf58

sleep 5s

#Mail Setup

emailtext="/home/ubuntu/instanceUtils/startStopScripts/Mail.txt"
echo "Reportwa-QA Instances server have been stopped successfully." >> $emailtext
sudo ssmtp keshav.goyal@hexaviewtech.com < $emailtext
#sudo ssmtp keshav.goyal@hexaviewtech.com, ankit.agarwal@hexaviewtech.com < $emailtext
head -n 6 $emailtext > temp.txt ; mv temp.txt $emailtext

