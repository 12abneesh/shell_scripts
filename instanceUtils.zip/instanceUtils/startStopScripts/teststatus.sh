#!/bin/bash
#region=us-west-1

read -p  "hello, your name?" name
echo "welcome, $name"
date=$(date "+%r")
echo $date
aws ec2 describe-security-groups --output json > /home/ubuntu/instanceUtils/startStopScripts/kestext.txt
#DONE 
aws instance start and mailing public dns
statusc=`aws ec2 describe-instances --output text --query 'Reservations[*].Instances[*].[State.[Code]]'  --region $region --instance-ids i-0a456655486cc3d07`
if [ $statusc -eq 80 ]; then
aws ec2 start-instances --region $region --instance-ids i-0a456655486cc3d07
if [ $? -eq 0 ]; then
sleep 1m
To get publicDNS of ML server
PublicDNS=`aws ec2 describe-instances --output text --query 'Reservations[*].Instances[*].[PublicDnsName]'  --region us-west-1 --instance-ids i-0a456655486cc3d07`
echo "public DNS: $PublicDNS"
fi
fi
