
#!/bin/bash


region=us-west-2
#aws ec2 describe-instances --query 'Reservations[*].Instances[*].InstanceId' -$

aws ec2 start-instances --region $region --instance-ids i-0e4c5e1acf3ed6aa0
aws ec2 start-instances --region $region --instance-ids i-08fbf1cf4c69bf3ea


sleep 180s

ssh -i /home/ubuntu/instanceUtils/stratstopIR/Hvt_Custom_Prod.pem ubuntu@35.165.103.86 'sudo -s /home/ubuntu/startstop/start.sh && exit'
if [ $? -eq 0 ]; then
#Mail Setup
emailtext="/home/ubuntu/instanceUtils/stratstopIR/email.txt"
echo "IR-PROD Instances have been started successfully" >> $emailtext
#sudo ssmtp keshav.goyal@hexaviewtech.com, ankit.agarwal@hexaviewtech.com, neha.kumari@hexaviewtech.com < $emailtext
head -n 6 $emailtext > temp.txt ; mv temp.txt $emailtext
fi

