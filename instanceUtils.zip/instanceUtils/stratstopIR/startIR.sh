
#!/bin/bash


region=us-west-2
#aws ec2 describe-instances --query 'Reservations[*].Instances[*].InstanceId' --region $region

aws ec2 start-instances --region $region --instance-ids i-0023355607e7cbd10

aws ec2 start-instances --region $region --instance-ids i-0a49b4dcacf9ae3dd


sleep 180s

ssh -i /home/ubuntu/instanceUtils/stratstopIR/IR_QA.pem  ubuntu@54.71.223.126 'sudo -s /home/ubuntu/startstop/startIR.sh && exit'
#if [ $? -eq 0 ]; then
#Mail Setup
#emailtext="/home/ubuntu/instanceUtils/stratstopIR/mail.txt"
#echo "IR-QA Instances have been started successfully" >> $emailtext
#sudo ssmtp keshav.goyal@hexaviewtech.com, ankit.agarwal@hexaviewtech.com, neha.kumari@hexaviewtech.com < $emailtext
#head -n 6 $emailtext > temp.txt ; mv temp.txt $emailtext
#fi
