#!/bin/bash

region=us-west-2
aws ec2 describe-instances --query 'Reservations[*].Instances[*].InstanceId' --region $region

ssh -i /home/ubuntu/instanceUtils/stratstopIR/IR_QA.pem  ubuntu@54.71.223.126 'sudo -s /home/ubuntu/startstop/stopIR.sh && exit'
if [ $? -eq 0 ]; then
echo "everthing is shutdown"
aws ec2 stop-instances --region $region --instance-ids i-0023355607e7cbd10
if [ $? -eq 0 ]; then
aws ec2 stop-instances --region $region --instance-ids i-0a49b4dcacf9ae3dd
if [ $? -eq 0 ]; then
#Mail Setup
emailtext="/home/ubuntu/instanceUtils/stratstopIR/mail.txt"
echo "IR-QA Instances have been stopped successfully" >> $emailtext
sudo ssmtp neha.kumari@hexaviewtech.com, ankit.agarwal@hexaviewtech.com, keshav.goyal@hexaviewtech.com < $emailtext
head -n 6 $emailtext > temp.txt ; mv temp.txt $emailtext
fi
fi
fi
